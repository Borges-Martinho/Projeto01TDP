import chalk from 'chalk';
import fs from 'fs';

function trataFalha(falha){
    throw new Error(chalk.red(falha.code, "Não há arquivos nessa rota"));
}

async function leiaoArquivo(caminhoDoArquivo){
    const endcoding = 'utf-8';
    const texto = await fs.promises.readFile(caminhoDoArquivo, endcoding)
    console.log(chalk.puple(texto))
    }

export default leiaoArquivo;