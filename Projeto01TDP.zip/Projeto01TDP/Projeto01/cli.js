import chalk from "chalk";
import pegaoArquivo from "./index.js";
import validaURL from "./http-validacao.js";
import leiaoArquivo from "./leitura.js";

const caminho = process.argv;

async function processaoTexto(caminhoDoArquivo){
    const resultado = await pegaoArquivo(caminhoDoArquivo[2]);
    
    if(caminho[3] === "correto"){
        console.log(chalk.yellow('Links corretos'), await validaURL(resultado));
    } else if(caminho[3] === "leitura"){
        console.log(await leiaoArquivo(caminhoDoArquivo[2]));
    } else if(caminho[3] === "links"){
        console.log(chalk.bgGreen('Lista de Links: '), resultado);
    } else{
        console.log(chalk.blueBright("Erro no sistema"))
    }
}

//console.log(pegaoArquivo(caminho[2]));

processaoTexto(caminho);