import chalk from 'chalk';
import fs from 'fs';

function extraiLinks(texto){
    const regex = /\[([^\]]*)\]\((https?:\/\/[^$#\s].[^\s]*)\)/gm;
    const arrayResultados= [];

    let temp;
    while((temp = regex.exec(texto)) != null){
        arrayResultados.push ({[temp[1]] : [temp[2]]})
    }
    return arrayResultados.length ===0 ? "Não há links" : arrayResultados;
}

function tratarFalha(falha){
    throw new Error(chalk.red(falha.code, "Não há arquivos nesta rota"));
}

async function pegaArquivo(rotaDoArquivo){
    const endcoding = 'utf-8';
    try{
        const texto = await fs.promises.readFile(rotaDoArquivo, endcoding)
        return(extraiLinks(texto))
    } catch(falha){
        tratarFalha(falha);
    }
}

export default pegaArquivo;